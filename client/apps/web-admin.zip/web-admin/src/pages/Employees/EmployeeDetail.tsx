// src/pages/Employees/EmployeeDetail.tsx

export default function EmployeeDetail() {
  return (
    <div>
      <h1>Chi tiết nhân viên</h1>
      <p>Trang chi tiết nhân viên đang được phát triển...</p>
    </div>
  );
}